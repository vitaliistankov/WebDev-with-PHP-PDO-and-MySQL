<?php

	$dsn = "mysql:host=sql102.epizy.com;dbname=remote_db";

	try {
		$pdo = new PDO($dsn, 'root', '');
	}
	catch(PDOException $e) {
		echo $e->getMessage();
	}

?>